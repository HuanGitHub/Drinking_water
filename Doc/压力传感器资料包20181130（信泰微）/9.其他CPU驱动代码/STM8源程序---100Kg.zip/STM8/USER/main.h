#ifndef MAIN_H
#define MAIN_H

typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned int   uint;

#endif